# WezTracker Release ZIP Build

## One-time GitHub setup

The repository must contain `.github/workflows/release-build.yml`.
Commit this project once so GitHub Actions knows about the workflow.

## Future builds

1. Create a GitHub Release.
2. Attach a source ZIP named exactly:
   `WezTracker-source.zip`
3. Publish the Release.
4. GitHub Actions downloads that ZIP, extracts it, builds the APK, and attaches:
   `WezTracker-v1.0.0.apk`

The source ZIP must contain the Android project, including
`settings.gradle.kts` or `settings.gradle`.
