package com.weztracker.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val amount: Double,
    val category: String,
    val note: String = "",
    val dateMillis: Long = System.currentTimeMillis()
)

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC") fun observeAll(): Flow<List<Transaction>>
    @Insert suspend fun insert(item: Transaction)
    @Delete suspend fun delete(item: Transaction)
    @Query("DELETE FROM transactions") suspend fun deleteAll()
}

@Database(entities = [Transaction::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    companion object { fun create(context: android.content.Context) = Room.databaseBuilder(context, AppDatabase::class.java, "weztracker.db").build() }
}
