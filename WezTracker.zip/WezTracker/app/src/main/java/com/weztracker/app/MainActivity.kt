package com.weztracker.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.*
import com.weztracker.app.data.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.launch

private val Income = Color(0xFF2E7D32)
private val Expense = Color(0xFFC62828)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { WezTrackerApp() } }
}

@Composable fun WezTrackerApp() {
    val db = remember { AppDatabase.create(androidx.compose.ui.platform.LocalContext.current) }
    val transactions by db.transactionDao().observeAll().collectAsStateWithLifecycle(emptyList())
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    var showAdd by remember { mutableStateOf(false) }
    val balance = transactions.sumOf { if (it.type == "income") it.amount else -it.amount }
    val income = transactions.filter { it.type == "income" }.sumOf { it.amount }
    val expenses = transactions.filter { it.type == "expense" }.sumOf { it.amount }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF315C4A), secondary = Color(0xFF8B6F47))) {
        Scaffold(bottomBar = { NavigationBar {
            NavigationBarItem(selected = nav.currentDestination?.route == "home", onClick = { nav.navigate("home") { launchSingleTop = true } }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
            NavigationBarItem(selected = nav.currentDestination?.route == "transactions", onClick = { nav.navigate("transactions") { launchSingleTop = true } }, icon = { Icon(Icons.Default.List, null) }, label = { Text("Transactions") })
            NavigationBarItem(selected = nav.currentDestination?.route == "reports", onClick = { nav.navigate("reports") { launchSingleTop = true } }, icon = { Icon(Icons.Default.PieChart, null) }, label = { Text("Reports") })
        }}) { pad ->
            NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                composable("home") { HomeScreen(balance, income, expenses, transactions.take(5), { showAdd = true }, { nav.navigate("transactions") }) }
                composable("transactions") { TransactionsScreen(transactions, { showAdd = true }, { scope.launch { db.transactionDao().delete(it) } }) }
                composable("reports") { ReportsScreen(transactions) }
            }
        }
    }
    if (showAdd) AddTransactionDialog(onDismiss = { showAdd = false }) { t -> scope.launch { db.transactionDao().insert(t); showAdd = false } }
}

fun money(v: Double): String = NumberFormat.getCurrencyInstance(Locale("en", "PH")).format(v)

@Composable fun HomeScreen(balance: Double, income: Double, expenses: Double, recent: List<Transaction>, onAdd: () -> Unit, onAll: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("WezTracker", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Your money, simply tracked.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) { Column(Modifier.padding(22.dp)) { Text("Current Balance", color = Color.White.copy(.8f)); Text(money(balance), color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold) } } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) { SummaryCard("Income", income, Income, Modifier.weight(1f)); SummaryCard("Expenses", expenses, Expense, Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) { Button(onClick = onAdd, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add") }; OutlinedButton(onClick = onAll, modifier = Modifier.weight(1f)) { Text("View all") } } }
        item { Text("Recent transactions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) }
        if (recent.isEmpty()) item { EmptyState() } else items(recent, key = { it.id }) { TransactionRow(it) }
    }
}

@Composable fun SummaryCard(title: String, value: Double, color: Color, modifier: Modifier) { Card(modifier) { Column(Modifier.padding(16.dp)) { Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(money(value), color = color, fontWeight = FontWeight.Bold) } } }

@Composable fun TransactionsScreen(items: List<Transaction>, onAdd: () -> Unit, onDelete: (Transaction) -> Unit) {
    Scaffold(floatingActionButton = { FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, "Add transaction") } }) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("Transactions", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("All your recorded money movements", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(8.dp)) }
            if (items.isEmpty()) item { EmptyState() } else items(items, key = { it.id }) { t -> TransactionRow(t, onDelete = { onDelete(t) }) }
        }
    }
}

@Composable fun TransactionRow(t: Transaction, onDelete: (() -> Unit)? = null) {
    val color = if (t.type == "income") Income else Expense
    Card { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(42.dp).background(color.copy(.12f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(if (t.type == "income") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = color) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(t.category, fontWeight = FontWeight.SemiBold); Text(if (t.note.isBlank()) SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(t.dateMillis)) else t.note, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }; Text((if (t.type == "income") "+" else "-") + money(t.amount), color = color, fontWeight = FontWeight.Bold); if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, "Delete") } } }
}

@Composable fun ReportsScreen(items: List<Transaction>) {
    val expenses = items.filter { it.type == "expense" }.groupingBy { it.category }.fold(0.0) { a, t -> a + t.amount }
    val total = expenses.values.sum()
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { item { Text("Reports", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("A simple view of where your money goes.", color = MaterialTheme.colorScheme.onSurfaceVariant) }; item { Card { Column(Modifier.padding(18.dp)) { Text("Total expenses", color = MaterialTheme.colorScheme.onSurfaceVariant); Text(money(total), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } } }; item { Text("Spending by category", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) }; if (expenses.isEmpty()) item { EmptyState() } else items(expenses.entries.sortedByDescending { it.value }) { (cat, value) -> Column { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(cat, fontWeight = FontWeight.SemiBold); Text(money(value), fontWeight = FontWeight.Bold) }; LinearProgressIndicator(progress = { if (total == 0.0) 0f else (value / total).toFloat() }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) } } }
}

@Composable fun EmptyState() { Card { Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.AccountBalanceWallet, null, Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.height(10.dp)); Text("Nothing here yet", fontWeight = FontWeight.SemiBold); Text("Add your first transaction to start tracking.", color = MaterialTheme.colorScheme.onSurfaceVariant) } } }

@Composable fun AddTransactionDialog(onDismiss: () -> Unit, onSave: (Transaction) -> Unit) {
    var type by remember { mutableStateOf("expense") }; var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Food") }; var note by remember { mutableStateOf("") }
    val categories = if (type == "expense") listOf("Food", "Transportation", "Bills", "Shopping", "Health", "Entertainment", "Other") else listOf("Salary", "Freelance", "Gift", "Other")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add transaction") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { Row(Modifier.fillMaxWidth()) { FilterChip(selected = type == "expense", onClick = { type = "expense" }, label = { Text("Expense") }); Spacer(Modifier.width(8.dp)); FilterChip(selected = type == "income", onClick = { type = "income" }, label = { Text("Income") }) }; OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Amount") }, singleLine = true); Text("Category", style = MaterialTheme.typography.labelLarge); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { categories.take(4).forEach { FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) }) } }; OutlinedTextField(note, { note = it }, label = { Text("Note (optional)") }, singleLine = true) } }, confirmButton = { Button(enabled = amount.toDoubleOrNull()?.let { it > 0 } == true, onClick = { onSave(Transaction(type = type, amount = amount.toDouble(), category = category, note = note)) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
