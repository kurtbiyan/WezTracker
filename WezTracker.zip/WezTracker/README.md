# WezTracker 💰

**WezTracker v1.0.0** is an offline-first personal money tracker for Android.

## Included in v1.0.0

- Home dashboard with current balance, income, expenses, and recent transactions
- Add income and expense records
- Local Room database — no account or internet required
- Transaction history with delete
- Spending report grouped by category
- Philippine peso currency formatting by default
- GitHub Actions workflow that builds a downloadable debug APK

## Build the APK with GitHub

1. Create a new GitHub repository named **WezTracker**.
2. Upload the contents of this project into the repository.
3. Commit the files to `main`.
4. Open the repository's **Actions** tab.
5. Select **Build WezTracker APK**.
6. Wait for the workflow to finish.
7. Open the completed workflow run and download **WezTracker-debug-apk** from Artifacts.
8. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone.

## Tech stack

- Kotlin
- Jetpack Compose + Material 3
- Room local database
- Navigation Compose
- GitHub Actions
- Android min SDK 26 / target SDK 35

## Package

`com.weztracker.app`
