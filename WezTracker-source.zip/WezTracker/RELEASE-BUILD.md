# WezTracker Release Build

This version fixes the Java/Kotlin JVM target mismatch by compiling both Java and Kotlin for Java 17.

## GitHub Release workflow

1. Commit this project once so `.github/workflows/release-build.yml` is present.
2. Create a GitHub Release.
3. Attach a source ZIP named exactly `WezTracker-source.zip`.
4. Publish the Release.
5. GitHub Actions extracts the source, builds the debug APK, and attaches `WezTracker-v1.0.0.apk` to the same Release.
